package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object fullName
     
    /**
     * <p></p>
     */
    public static Object leaveType
     
    /**
     * <p></p>
     */
    public static Object originalLeaveBal
     
    /**
     * <p></p>
     */
    public static Object status
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += TestCaseMain.getParsedValues(RunConfiguration.getOverridingParameters())
    
            fullName = selectedVariables['fullName']
            leaveType = selectedVariables['leaveType']
            originalLeaveBal = selectedVariables['originalLeaveBal']
            status = selectedVariables['status']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
