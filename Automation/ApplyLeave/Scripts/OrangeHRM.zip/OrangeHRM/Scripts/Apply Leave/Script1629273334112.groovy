import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

CustomKeywords.'com.database.mysql.connectDB'('localhost', 'orangehrm_mysql', '3306', 'root', null)
CustomKeywords.'com.database.mysql.execute'("DELETE FROM `ohrm_leave_request` WHERE `emp_number`=3 AND `date_applied`='2021-09-02' AND `leave_type_id` = 3")

CustomKeywords.'com.database.mysql.execute'('DELETE FROM `ohrm_leave` WHERE `emp_number` = 3 AND `leave_type_id`=3 and (`date`=\'2021-09-02\' or `date`=\'2021-09-03\') ')

CustomKeywords.'com.database.mysql.closeDatabaseConnection'()

WebUI.navigateToUrl('http://localhost/orangehrm/symfony/web/index.php/dashboard')

WebUI.click(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/img'))

WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/select_--Select--MarriageMaternityPersonalS_480ad7'), 
    '3', true)

WebUI.setText(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/input__applyleavetxtFromDate'), from)

WebUI.sendKeys(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/input__applyleavetxtFromDate'), Keys.chord(Keys.ENTER))

WebUI.setText(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/input__applyleavetxtToDate'), to)

WebUI.sendKeys(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/input__applyleavetxtToDate'), Keys.chord(Keys.ENTER))

if (from.equals(to)) {
    WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/select_Full DayHalf DaySpecify Time'), 
        duration1, true)

    if (duration1.equals('half_day')) {
        WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/select_MorningAfternoon'), 
            duration2, true)
    }
    
    if (duration1.equals('specify_time')) {
        WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/select_000000150030004501000115013001450200_bef9c6'), 
            duration2, true)

        WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/select_000000150030004501000115013001450200_bef9c6_1'), 
            duration3, true //start day
            //end day
            )
    } //		WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/applyleave_firstDuration_duration'),
    //			duration1, true)
    //
    //		if (duration1.equals('half_day')) {
    //			WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/applyleave_firstDuration_ampm'),
    //				duration2, true)
    //		}
    //		
    //		if (duration1.equals('specify_time')) {
    //			WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/select_000000150030004501000115013001450200_bef9c6_1_2'),
    //				duration2, true)
    //
    //			WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/select_000000150030004501000115013001450200_bef9c6_1_2_3'),
    //				duration3, true)
    //		}
    ///-----------------------------------------
} else {
    WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/select_NoneAll DaysStart Day OnlyEnd Day On_3e5258'), 
        partialDays, true)

    if (partialDays.equals('all') || partialDays.equals('start')) {
        WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/applyleave_firstDuration_duration'), 
            duration1, true)

        if (duration1.equals('half_day')) {
            WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/applyleave_firstDuration_ampm'), 
                duration2, true)
        }
        
        if (duration1.equals('specify_time')) {
            WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/select_000000150030004501000115013001450200_bef9c6_1_2'), 
                duration2, true)

            WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/select_000000150030004501000115013001450200_bef9c6_1_2_3'), 
                duration3, true)
        }
    }
    
    if (partialDays.equals('end')) {
        WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/select_Half DaySpecify Time_1'), 
            duration1, true)

        if (duration1.equals('half_day')) {
            WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/select_MorningAfternoon_1'), 
                duration2, true)
        }
        
        if (duration1.equals('specify_time')) {
            WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/applyleave_secondDuration_time_from'), 
                duration2, true)

            WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/applyleave_secondDuration_time_to'), 
                duration3, true)
        }
    }
    
    if (partialDays.equals('start_end')) {
        WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/applyleave_firstDuration_duration'), 
            duration1, true)

        if (duration1.equals('half_day')) {
            WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/applyleave_firstDuration_ampm'), 
                duration2, true)
        }
        
        if (duration1.equals('specify_time')) {
            WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/select_000000150030004501000115013001450200_bef9c6_1_2'), 
                duration2, true)

            WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/select_000000150030004501000115013001450200_bef9c6_1_2_3'), 
                duration3, true)
        }
        
        WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/select_Half DaySpecify Time_1'), 
            duration4, true)

        if (duration4.equals('half_day')) {
            WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/select_MorningAfternoon_1'), 
                duration5, true)
        }
        
        if (duration4.equals('specify_time')) {
            WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/applyleave_secondDuration_time_from'), 
                duration5, true)

            WebUI.selectOptionByValue(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/applyleave_secondDuration_time_to'), 
                duration6, true)
        }
    }
}

WebUI.scrollToElement(findTestObject('Apply Leave/Page_OrangeHRM/input__applyBtn'), 0)

WebUI.takeScreenshot()

//apply leave
WebUI.click(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/input__applyBtn'))

WebUI.navigateToUrl('http://localhost/orangehrm/symfony/web/index.php/leave/viewMyLeaveList/reset/1')

WebUI.setText(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/input_From_leaveListcalFromDate'), from)

WebUI.sendKeys(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/input_From_leaveListcalFromDate'), Keys.chord(
        Keys.ENTER))

WebUI.setText(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/input_To_leaveListcalToDate'), to)

WebUI.sendKeys(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/input_To_leaveListcalToDate'), Keys.chord(Keys.ENTER))

WebUI.uncheck(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/input_All_leaveList_chkSearchFilter_checkbo_a698f3'))

WebUI.check(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/input_Pending Approval_leaveListchkSearchFilter'))

WebUI.click(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/input_Taken_btnSearch'))

WebUI.scrollToElement(findTestObject('Apply Leave/Page_OrangeHRM/th_Date'), 0)

//xem ket qua search
WebUI.takeScreenshot()

if (days.equals('')) {
    WebUI.verifyMatch(WebUI.getText(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/td_No Records Found')), 
        'No Records Found', false, FailureHandling.STOP_ON_FAILURE //Pending Approval(1.00)
        //    WebUI.selectOptionByValue(findTestObject('Apply Leave/Page_OrangeHRM/select_Select ActionCancel_1'), '91', true, FailureHandling.STOP_ON_FAILURE)
        ) //
    //    WebUI.click(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/input_Pending Approval(1.00)_btnSave'))
} else {
    WebUI.verifyMatch(WebUI.getText(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/a_2021-09-02 to 2021-09-03')), 
        date, false, FailureHandling.STOP_ON_FAILURE)

    WebUI.verifyMatch(WebUI.getText(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/a_Rachel Morris')), GlobalVariable.fullName, 
        false, FailureHandling.STOP_ON_FAILURE)

    WebUI.verifyMatch(WebUI.getText(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/td_Personal')), GlobalVariable.leaveType, 
        false, FailureHandling.STOP_ON_FAILURE)

    WebUI.verifyMatch(Double.parseDouble(WebUI.getText(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/td_49.25'))).toString(), 
        (GlobalVariable.originalLeaveBal - Double.parseDouble(days)).toString(), false, FailureHandling.STOP_ON_FAILURE)

    WebUI.verifyMatch(WebUI.getText(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/td_0.75')), days, false, 
        FailureHandling.STOP_ON_FAILURE)

    WebUI.verifyMatch(WebUI.getText(findTestObject('Object Repository/Apply Leave/Page_OrangeHRM/a_Pending Approval(0.75)')), 
        ((GlobalVariable.status + '(') + days) + ')', false, FailureHandling.STOP_ON_FAILURE)
}

