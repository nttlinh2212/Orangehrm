<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>html_OrangeHRM                             _e80fcb</name>
   <tag></tag>
   <elementGuidId>7f4d6842-70bd-472e-a44e-ef52b5969b6f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*/text()[normalize-space(.)='']/parent::*</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>html.fontawesome-i2svg-active.fontawesome-i2svg-complete</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>html</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xmlns</name>
      <type>Main</type>
      <value>http://www.w3.org/1999/xhtml</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xml:lang</name>
      <type>Main</type>
      <value>en</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>lang</name>
      <type>Main</type>
      <value>en</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fontawesome-i2svg-active fontawesome-i2svg-complete</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

        OrangeHRM
        
        
                
        svg:not(:root).svg-inline--fa{overflow:visible}.svg-inline--fa{display:inline-block;font-size:inherit;height:1em;overflow:visible;vertical-align:-.125em}.svg-inline--fa.fa-lg{vertical-align:-.225em}.svg-inline--fa.fa-w-1{width:.0625em}.svg-inline--fa.fa-w-2{width:.125em}.svg-inline--fa.fa-w-3{width:.1875em}.svg-inline--fa.fa-w-4{width:.25em}.svg-inline--fa.fa-w-5{width:.3125em}.svg-inline--fa.fa-w-6{width:.375em}.svg-inline--fa.fa-w-7{width:.4375em}.svg-inline--fa.fa-w-8{width:.5em}.svg-inline--fa.fa-w-9{width:.5625em}.svg-inline--fa.fa-w-10{width:.625em}.svg-inline--fa.fa-w-11{width:.6875em}.svg-inline--fa.fa-w-12{width:.75em}.svg-inline--fa.fa-w-13{width:.8125em}.svg-inline--fa.fa-w-14{width:.875em}.svg-inline--fa.fa-w-15{width:.9375em}.svg-inline--fa.fa-w-16{width:1em}.svg-inline--fa.fa-w-17{width:1.0625em}.svg-inline--fa.fa-w-18{width:1.125em}.svg-inline--fa.fa-w-19{width:1.1875em}.svg-inline--fa.fa-w-20{width:1.25em}.svg-inline--fa.fa-pull-left{margin-right:.3em;width:auto}.svg-inline--fa.fa-pull-right{margin-left:.3em;width:auto}.svg-inline--fa.fa-border{height:1.5em}.svg-inline--fa.fa-li{width:2em}.svg-inline--fa.fa-fw{width:1.25em}.fa-layers svg.svg-inline--fa{bottom:0;left:0;margin:auto;position:absolute;right:0;top:0}.fa-layers{display:inline-block;height:1em;position:relative;text-align:center;vertical-align:-.125em;width:1em}.fa-layers svg.svg-inline--fa{-webkit-transform-origin:center center;transform-origin:center center}.fa-layers-counter,.fa-layers-text{display:inline-block;position:absolute;text-align:center}.fa-layers-text{left:50%;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);-webkit-transform-origin:center center;transform-origin:center center}.fa-layers-counter{background-color:#ff253a;border-radius:1em;-webkit-box-sizing:border-box;box-sizing:border-box;color:#fff;height:1.5em;line-height:1;max-width:5em;min-width:1.5em;overflow:hidden;padding:.25em;right:0;text-overflow:ellipsis;top:0;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:top right;transform-origin:top right}.fa-layers-bottom-right{bottom:0;right:0;top:auto;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:bottom right;transform-origin:bottom right}.fa-layers-bottom-left{bottom:0;left:0;right:auto;top:auto;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:bottom left;transform-origin:bottom left}.fa-layers-top-right{right:0;top:0;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:top right;transform-origin:top right}.fa-layers-top-left{left:0;right:auto;top:0;-webkit-transform:scale(.25);transform:scale(.25);-webkit-transform-origin:top left;transform-origin:top left}.fa-lg{font-size:1.3333333333em;line-height:.75em;vertical-align:-.0667em}.fa-xs{font-size:.75em}.fa-sm{font-size:.875em}.fa-1x{font-size:1em}.fa-2x{font-size:2em}.fa-3x{font-size:3em}.fa-4x{font-size:4em}.fa-5x{font-size:5em}.fa-6x{font-size:6em}.fa-7x{font-size:7em}.fa-8x{font-size:8em}.fa-9x{font-size:9em}.fa-10x{font-size:10em}.fa-fw{text-align:center;width:1.25em}.fa-ul{list-style-type:none;margin-left:2.5em;padding-left:0}.fa-ul>li{position:relative}.fa-li{left:-2em;position:absolute;text-align:center;width:2em;line-height:inherit}.fa-border{border:solid .08em #eee;border-radius:.1em;padding:.2em .25em .15em}.fa-pull-left{float:left}.fa-pull-right{float:right}.fa.fa-pull-left,.fab.fa-pull-left,.fal.fa-pull-left,.far.fa-pull-left,.fas.fa-pull-left{margin-right:.3em}.fa.fa-pull-right,.fab.fa-pull-right,.fal.fa-pull-right,.far.fa-pull-right,.fas.fa-pull-right{margin-left:.3em}.fa-spin{-webkit-animation:fa-spin 2s infinite linear;animation:fa-spin 2s infinite linear}.fa-pulse{-webkit-animation:fa-spin 1s infinite steps(8);animation:fa-spin 1s infinite steps(8)}@-webkit-keyframes fa-spin{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}@keyframes fa-spin{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}.fa-rotate-90{-webkit-transform:rotate(90deg);transform:rotate(90deg)}.fa-rotate-180{-webkit-transform:rotate(180deg);transform:rotate(180deg)}.fa-rotate-270{-webkit-transform:rotate(270deg);transform:rotate(270deg)}.fa-flip-horizontal{-webkit-transform:scale(-1,1);transform:scale(-1,1)}.fa-flip-vertical{-webkit-transform:scale(1,-1);transform:scale(1,-1)}.fa-flip-both,.fa-flip-horizontal.fa-flip-vertical{-webkit-transform:scale(-1,-1);transform:scale(-1,-1)}:root .fa-flip-both,:root .fa-flip-horizontal,:root .fa-flip-vertical,:root .fa-rotate-180,:root .fa-rotate-270,:root .fa-rotate-90{-webkit-filter:none;filter:none}.fa-stack{display:inline-block;height:2em;position:relative;width:2.5em}.fa-stack-1x,.fa-stack-2x{bottom:0;left:0;margin:auto;position:absolute;right:0;top:0}.svg-inline--fa.fa-stack-1x{height:1em;width:1.25em}.svg-inline--fa.fa-stack-2x{height:2em;width:2.5em}.fa-inverse{color:#fff}.sr-only{border:0;clip:rect(0,0,0,0);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px}.sr-only-focusable:active,.sr-only-focusable:focus{clip:auto;height:auto;margin:0;overflow:visible;position:static;width:auto}.svg-inline--fa .fa-primary{fill:var(--fa-primary-color,currentColor);opacity:1;opacity:var(--fa-primary-opacity,1)}.svg-inline--fa .fa-secondary{fill:var(--fa-secondary-color,currentColor);opacity:.4;opacity:var(--fa-secondary-opacity,.4)}.svg-inline--fa.fa-swap-opacity .fa-primary{opacity:.4;opacity:var(--fa-secondary-opacity,.4)}.svg-inline--fa.fa-swap-opacity .fa-secondary{opacity:1;opacity:var(--fa-primary-opacity,1)}.svg-inline--fa mask .fa-primary,.svg-inline--fa mask .fa-secondary{fill:#000}.fad.fa-inverse{color:#fff}
        
        
        
        
        
        
        
        
        
        
        
















   
        
        
                



    

















#katalon{font-family:monospace;font-size:13px;background-color:rgba(0,0,0,.7);position:fixed;top:0;left:0;right:0;display:block;z-index:999999999;line-height: normal} #katalon div{padding:0;margin:0;color:#fff;} #katalon kbd{display:inline-block;padding:3px 5px;font:13px Consolas,&quot;Liberation Mono&quot;,Menlo,Courier,monospace;line-height:10px;color:#555;vertical-align:middle;background-color:#fcfcfc;border:1px solid #ccc;border-bottom-color:#bbb;border-radius:3px;box-shadow:inset 0 -1px 0 #bbb;font-weight: bold} div#katalon-spy_elementInfoDiv {color: lightblue; padding: 0px 5px 5px} div#katalon-spy_instructionDiv {padding: 5px 5px 2.5px}
    

        

            
                
                Welcome Hoang
                


    
        
        
    




    

        
        
            
                
                                    
                No new notifications
                
                                    
            
        
    

    
        
            
                
                                    
            

        

        
            


        

        
            

        
    




    
        
            

        
            
        

    



    
        
            Success!        
        
            Successfully Saved        
        
            Successfully Shared        
        
            Successfully Deleted        

    




    
        
            
        
    





    
        People who shared this post    
    
        
            
        

    





    
        People who like this post    
    
        
            
        

    




    var getAccessUrl = '/orangehrm/orangehrm-4.5/symfony/web/index.php/buzz/getLogedToBuzz';
    var loginpageURL = '/orangehrm/orangehrm-4.5/symfony/web/index.php/auth/login';

    // buzzCommon.js
    var viewLikedEmployees = '/orangehrm/orangehrm-4.5/symfony/web/index.php/buzz/viewLikedEmployees';
    var addBuzzCommentURL = '/orangehrm/orangehrm-4.5/symfony/web/index.php/buzz/addNewComment';
    var shareShareURL = '/orangehrm/orangehrm-4.5/symfony/web/index.php/buzz/shareAPost';
    var getLikedEmployeeListURL = '/orangehrm/orangehrm-4.5/symfony/web/index.php/buzz/getLikedEmployeeList';

    // buzzNew.js
    var shareLikeURL = '/orangehrm/orangehrm-4.5/symfony/web/index.php/buzz/likeOnShare';
    var commentLikeURL = '/orangehrm/orangehrm-4.5/symfony/web/index.php/buzz/likeOnComment';
    var getSharedEmployeeListURL = '/orangehrm/orangehrm-4.5/symfony/web/index.php/buzz/getSharedEmployeeList';

    // viewNotificationComponent.js
    var viewMoreShare = '/orangehrm/orangehrm-4.5/symfony/web/index.php/buzz/viewShare';
    var buzzURL = &quot;/orangehrm/orangehrm-4.5/symfony/web/index.php/buzz/viewBuzz&quot;;
    var ClearNotificationURL = &quot;/orangehrm/orangehrm-4.5/symfony/web/index.php/buzz/clearNotificationAjax&quot;;
    var ClickOnNotificationIconURL = &quot;/orangehrm/orangehrm-4.5/symfony/web/index.php/buzz/clickOnNotificationIconAjax&quot;;
    var lang_NoNewNotifications = 'No new notifications';
    var lang_NotificationClearFailed = 'Failed to clear notifications';

                


    
        
    

                                    
                        
                    
                    
                        
                    
                                
                    var marketplaceURL = &quot;/orangehrm/orangehrm-4.5/symfony/web/index.php/marketPlace/ohrmAddons&quot;;
                    var SubscriberURL = &quot;/orangehrm/orangehrm-4.5/symfony/web/index.php/pim/subscriber&quot;;
                
                
                    
                        
    About

    
        
            ×
            About
        
        
            
                
                    
                        
                            Company Name: GroupE1
                        
                        
                            Version: Orangehrm OS 4.5
                        
                        
                            Active Employees: 2
                        
                        
                            Employees Terminated: 0
                        
                    
                
                
                        
    



    jQuery(document).ready(function() {
        
               
        jQuery('#aboutDisplayLink').click(function(event) {
            event.stopImmediatePropagation();
            jQuery('#messageToDisplayAbout').css(
                    'display', 'none');
            jQuery('#displayAbout').modal();
            jQuery('#help-menu.panelContainer').attr('style', 'display:block');
            
            var test = jQuery('.panelContainer');
            jQuery('#help-menu.panelContainer').css(
                    'display', 'block');
             
        });

        jQuery('#heartbeatSubmitBtn').click(function(event) {
            event.stopImmediatePropagation();
            jQuery(this).closest('form').ajaxSubmit(function() {
                jQuery('#messageToDisplayAbout').html('Saved');

                if (jQuery('#register_registration').is(':checked')) {
                    jQuery('#registration-section').css(
                            'display', 'none');
                }
                jQuery('#displayAbout').modal('hide');
                jQuery('#messageToDisplayAbout').css(
                        'display', 'block');
                jQuery('#welcome-menu').css('display','none');
            });
        });

        jQuery('#displayAbout').click(function(event) {
            event.stopImmediatePropagation();
        });
        
        jQuery('#heartbeatCancelBtn').click(function(event) {
            event.stopImmediatePropagation();
             jQuery('#welcome-menu').css('display','none');
                 jQuery('#displayAbout').modal('hide');
        });

    })



                        Change Password
                        Logout
                    
                
                                


    svg path,
    svg rect{
        fill: #FF6700;
    }
    .svgcl{
        position: relative;
        left: -35px;
        top: -31px;
    }
    


    var inputDatePattern = 'Y-m-d' ;
    var separatorString = 'to';
    $( document ).ready(function() {

        $(&quot;#loader-1&quot;).hide();
        empId = location.href[location.href.length-1];
        dates = $('#startDates').find(&quot;:selected&quot;).text().split(&quot; &quot;+separatorString+&quot; &quot;);
        startDate_timesheet = dates[0]+&quot; 00:00:00&quot;;
        endDate_timesheet   = dates[1]+&quot; 00:00:00&quot;;

        clientId  =     &quot;&quot;;
        clientSecret  = &quot;&quot;;
        clientUrl     = &quot;&quot;;
        successUrl  = &quot;&quot;;
        ajaxURL = &quot;/orangehrm/orangehrm-4.5/symfony/web/index.php/buzz/viewBuzz&quot;;
        var timeSheetStatus = $('#timesheet_status').find('h2').text();
        if(timeSheetStatus == 'Status: Approved'){

            $('.syncToggl').hide();
        } else {
            $('.syncToggl').show();
        }

    });

        
    function ajaxSyc() {
        $(&quot;#loader-1&quot;).show();

        $.ajax({
                type: &quot;POST&quot;,
                url: ajaxURL,
                data: {
                    'employee_Id':employeeId,
                    'startTime': startDate_timesheet,
                    'endTime': endDate_timesheet,
                    'timeFormat': inputDatePattern,
                    'timeZone': 'GMT'+formatTimeZone()
                },
                contentType: &quot;application/x-www-form-urlencoded&quot;,

                success: function (msg, status, jqXHR) {

                    $(&quot;#loader-1&quot;).hide();
                    msg = JSON.parse(msg);
                    msgCode = msg.statusCode;
                    if (msgCode != null) {
                        if (msgCode == 101) {
                            displayMessages('error',msg.description );
                        } else if (msgCode == 102) {

                            displayMessages('success', msg.description);
                            setTimeout(function () {
                                location.reload();
                            }, 2000);

                        }
                    } else {
                        showErrorMsg();
                    }

                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    $(&quot;#loader-1&quot;).hide();
                    console.log(errorThrown);
                    showErrorMsg();
                }
            });
    }
    
    function startSyc() {
        $(&quot;#loader-1&quot;).show();

    $.ajax({

        type: &quot;POST&quot;,
        url: clientUrl,


        data: {
            'grant_type': 'client_credentials',
            'client_id': clientId,
            'client_secret': clientSecret
        },
        contentType: &quot;application/x-www-form-urlencoded&quot;,


        success: function (msg, status, jqXHR) {

            try {

                msg = $.parseJSON(jqXHR.responseText);

            } catch (err) {
                console.log(err);
                showErrorMsg();
            }

            $.ajax({
                type: &quot;POST&quot;,
                url: successUrl,
                beforeSend: function (xhr) {

                    xhr.setRequestHeader(&quot;Authorization&quot;, &quot;Bearer &quot; + msg.access_token);
                },

                data: {

                    'employee_Id':employeeId,
                    'startTime': startDate_timesheet,
                    'endTime': endDate_timesheet,
                    'timeFormat': inputDatePattern,
                    'timeZone': 'GMT'+formatTimeZone()
                },
                contentType: &quot;application/x-www-form-urlencoded&quot;,

                success: function (msg, status, jqXHR) {

                    $(&quot;#loader-1&quot;).hide();
                    msgCode = msg.statusCode;
                    if (msgCode != null) {
                        if (msgCode == 101) {
                            displayMessages('error',msg.description );
                        } else if (msgCode == 102) {

                            displayMessages('success', msg.description);
                            setTimeout(function () {
                                location.reload();
                            }, 2000);

                        }
                    } else {
                        showErrorMsg();
                    }

                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    $(&quot;#loader-1&quot;).hide();
                    console.log(errorThrown);
                    showErrorMsg();
                }
            });

        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            $(&quot;#loader-1&quot;).hide();
            console.log(errorThrown);
            showErrorMsg();
        }


    });

    }

    function showErrorMsg(){
        displayMessages('error','Unable To Sync With Toggl' );
        setTimeout(function () {
            $('#msgDiv').remove();
        }, 3000);

    }




    
    
        
            
  
      
  
  
        
    

    
        
            ×
            Confirm Toggl Sync
        
        
            Any existing timesheet entry will be overwritten if record for same date is matched. Click ok to continue.
        
        
                            
                        
        
    






             

            

    
    
        
        
            Admin

            
                        
                    
                    
                    User Management

                        
                            

                                
                                    Users

                                
                             

                        
                           
                    
                    
                    Job

                        
                            

                                
                                    Job Titles

                                
                                    Pay Grades

                                
                                    Employment Status

                                
                                    Job Categories

                                
                                    Work Shifts

                                
                             

                        
                           
                    
                    
                    Organization

                        
                            

                                
                                    General Information

                                
                                    Locations

                                
                                    Structure

                                
                             

                        
                           
                    
                    
                    Qualifications

                        
                            

                                
                                    Skills

                                
                                    Education

                                
                                    Licenses

                                
                                    Languages

                                
                                    Memberships

                                
                             

                        
                           
                    
                    
                    Nationalities

                        
                           
                    
                    
                    Configuration

                        
                            

                                
                                    Email Configuration

                                
                                    Email Subscriptions

                                
                                    Localization

                                
                                    Modules

                                
                                    Social Media Authentication

                                
                                    Register OAuth Client

                                
                             

                        
                           
                    
                                                
                                         
            
            
        
            PIM

            
                        
                    
                    
                    Configuration

                        
                            

                                
                                    Optional Fields

                                
                                    Custom Fields

                                
                                    Data Import

                                
                                    Reporting Methods

                                
                                    Termination Reasons

                                
                             

                        
                           
                    
                    
                    Employee List

                        
                           
                    
                    
                    Add Employee

                        
                           
                    
                    
                    Reports

                        
                           
                    
                                                
                                         
            
            
        
            Leave

            
                                    
                        
                            
                                         
            
            
        
            Time

            
                                    
                        
                            
                                         
            
            
        
            Recruitment

            
                        
                    
                    
                    Candidates

                        
                           
                    
                    
                    Vacancies

                        
                           
                    
                                                
                                         
            
            
        
            My Info

            
                                    
                        
                            
                                         
            
            
        
            Performance

            
                        
                    
                    
                    Configure

                        
                            

                                
                                    KPIs

                                
                                    Trackers

                                
                             

                        
                           
                    
                    
                    Manage Reviews

                        
                            

                                
                                    Manage Reviews

                                
                                    My Reviews

                                
                                    Review List

                                
                             

                        
                           
                    
                    
                    My Trackers

                        
                           
                    
                    
                    Employee Trackers

                        
                           
                    
                                                
                                         
            
            
        
            Dashboard

            
                                    
                        
                            
                                         
            
            
        
            Directory

            
                                    
                        
                            
                                         
            
            
        
            Maintenance

            
                        
                    
                    
                    Purge Records

                        
                            

                                
                                    Employee Records

                                
                                    Candidate Records

                                
                             

                        
                           
                    
                    
                    Access Records

                        
                           
                    
                                                
                                         
            
            
        
            Buzz

            
                                    
                        
                            
                                         
            
            
                    
     
    
&lt;> 
            

                  

    
    
        Add User
    
        
    
        
        



                    

                

                    
                        User Role *
  
Admin
ESS


Employee Name *
  

Employee does not exist



        

            var employees_systemUser_employeeName = [{&quot;name&quot;:&quot;Hoang Nguyen&quot;,&quot;id&quot;:&quot;1&quot;},{&quot;name&quot;:&quot;Le Thi Hoa&quot;,&quot;id&quot;:&quot;2&quot;}];

            $(document).ready(function() {
            
                var nameField = $(&quot;#systemUser_employeeName_empName&quot;);
                var idStoreField = $(&quot;#systemUser_employeeName_empId&quot;);
                var typeHint = 'Type for hints...';
                var hintClass = 'inputFormatHint';
                var loadingMethod = '';
                var loadingHint = 'Loading';
            
                if (idStoreField.val() != '') {
                    idStoreField.data('item.name', nameField.val());
                }
                
                nameField.data('typeHint', typeHint);
                nameField.data('loadingHint', loadingHint);
                
                nameField.one('focus', function() {

                        if ($(this).hasClass(hintClass)) {
                            $(this).val(&quot;&quot;);
                            $(this).removeClass(hintClass);
                        }

                    });
                    
                if( loadingMethod != 'ajax'){
                    if (nameField.val() == '' || nameField.val() == typeHint) {
                        nameField.val(typeHint).addClass(hintClass);
                    }

                    

                    nameField.autocomplete(employees_systemUser_employeeName, {

                        formatItem: function(item) {
                            return $('&lt;div/>').text(item.name).html();
                        },
                        formatResult: function(item) {
                            return item.name
                        }
                      ,matchContains:true
                        }).result(function(event, item) {
                            idStoreField.val(item.id);
                            idStoreField.data('item.name', item.name);
                        }

                    );
                 }else{
                        var value = nameField.val().trim();
                        nameField.val(loadingHint).addClass('ac_loading');
                        $.ajax({
                               url: &quot;/orangehrm/orangehrm-4.5/symfony/web/index.php/pim/getEmployeeListAjax&quot;,
                               data: '',
                               dataType: 'json',
                               success: function(employeeList){

                                     nameField.autocomplete(employeeList, {

                                                formatItem: function(item) {
                                                    return $('&lt;div/>').text(item.name).html();
                                                },
                                                formatResult: function(item) {
                                                    return item.name
                                                }
                                                
                                                ,matchContains:true
                                            }).result(function(event, item) {
                                                idStoreField.val(item.id);
                                                idStoreField.data('item.name', item.name);
                                            }

                                        );
                                         nameField.removeClass('ac_loading'); 
                                        
                                         if(value==''){
                                            nameField.val(typeHint).addClass(hintClass);
                                         } else {
                                            nameField.val(value).addClass();
                                         }
                                    }
                             });
                 }
                
            }); // End of $(document).ready

                 
        



Username *
  Should have at least 5 characters

Status *
  
Enabled
Disabled


Change Password
  

Password *
  Your password must contain a lower-case letter, an upper-case letter, a digit and a special character. Try a different password.StrongestFor a strong password, please use a hard to guess combination of text with upper and lower case characters, symbols and numbers
        var passwordOptions = [
        'Very Weak', 'Weak', 'Better',
        'Medium', 'Strong', 'Strongest'
    ];
        
        $(document).ready(function() {
           $('#systemUser_password').on('keyup', function(){
              showPasswordStrength($('#systemUser_password').val(), '/orangehrm/orangehrm-4.5/symfony/web/index.php/securityAuthentication/getPasswordStrengthAjax', 'systemUser_password', passwordOptions );
           });         
        });
    

Confirm Password *
  Passwords do not match



                        
                            * Required field                        
                    

                    
                        
                        
                    

                

            
        
    




	
    var user_UserNameRequired       = 'Required';
    var user_EmployeeNameRequired   = 'Required';
    var user_ValidEmployee          = 'Employee does not exist';
    var user_UserPaswordRequired    = 'Required';
    var user_UserConfirmPassword    = 'Required';
    var user_samePassword           = &quot;Passwords do not match&quot;;
    var user_Max20Chars             = 'Should be less than 64 characters';
    var user_editLocation           = &quot;Edit User&quot;;
    var userId                      = &quot;&quot;;
    var user_save                   = &quot;Save&quot;;
    var user_edit                   = &quot;Edit&quot;;
    var user_typeForHints           = &quot;Type for hints...&quot;;
    var user_name_alrady_taken      = 'Already exists';
    var isUniqueUserUrl             = '/orangehrm/orangehrm-4.5/symfony/web/index.php/admin/isUniqueUserJson';
    var viewSystemUserUrl           = '/orangehrm/orangehrm-4.5/symfony/web/index.php/admin/viewSystemUsers';
    var user_UserNameLength         = 'Should have at least 5 characters';
    var user_UserPasswordLength     = 'Should have at least 8 characters';
    var password_user               = &quot;Very Weak,Weak,Better,Medium,Strong,Strongest&quot;;
    var isEditMode                  = 'false';
    var ldapInstalled               = 'false';
    var validator = null;
    var openIdEnabled = &quot;on&quot;;
    var lang_maxLengthExceeds = 'Password length should be less than 64 characters. Try a different password.';
    var lang_passwordStrengthInvalid = 'Your password must contain a lower-case letter, an upper-case letter, a digit and a special character. Try a different password.';
    var requiredStrengthCheckUrl = '/orangehrm/orangehrm-4.5/symfony/web/index.php/securityAuthentication/checkMinimumRequiredPasswordStrengthAjax';




             

         

        
            OrangeHRM 4.5
© 2005 - 2021 OrangeHRM, Inc. All rights reserved.
         


 
        

            $(document).ready(function() {                            
                
                /* Enabling tooltips */
                $(&quot;.tiptip&quot;).tipTip();

                /* Toggling header menus */
                $(&quot;#welcome&quot;).click(function () {
                    $(&quot;#welcome-menu&quot;).slideToggle(&quot;fast&quot;);
                    $(this).toggleClass(&quot;activated-welcome&quot;);
                    return false;
                });
                
                $(&quot;#help&quot;).click(function () {
                    $(&quot;#help-menu&quot;).slideToggle(&quot;fast&quot;);
                    $(this).toggleClass(&quot;activated-help&quot;);
                    return false;
                });
                
                $('.panelTrigger').outside('click', function() {
                    $('.panelContainer').stop(true, true).slideUp('fast');
                });                

                /* 
                 * Button hovering effects 
                 * Note: we are not using pure css using :hover because :hover applies to even disabled elements.
                 * The pseudo class :enabled is not supported in IE &lt; 9.
                 */                
                $(document).on({
                    mouseenter: function () {
                        $(this).addClass('hover');                        
                    },
                    mouseleave: function () {
                        $(this).removeClass('hover');                        
                    }

                }, 'input[type=button], input[type=submit], input[type=reset]'); 
  
                /* Fading out main messages */
                $(document).on({
                    click: function() {
                        $(this).parent('div.message').fadeOut(&quot;slow&quot;);
                    }
                }, '.message a.messageCloseButton');                

                /* Toggling search form: Begins */
                //$(&quot;.toggableForm .inner&quot;).hide(); // Disabling this makes search forms to be expanded by default.

                $(&quot;.toggableForm .toggle&quot;).click(function () {
                    $(&quot;.toggableForm .inner&quot;).slideToggle('slow', function() {
                        if($(this).is(':hidden')) {
                            $('.toggableForm .tiptip').tipTip({content:'Expand for Options'});
                        } else {
                            $('.toggableForm .tiptip').tipTip({content:'Hide Options'});
                        }
                    });
                    $(this).toggleClass(&quot;activated&quot;);
                });
                /* Toggling search form: Ends */

                /* Enabling/disabling form fields: Begin */
                
                $('form.clickToEditForm input, form.clickToEditForm select, form.clickToEditForm textarea').attr('disabled', 'disabled');
                $('form.clickToEditForm input.calendar').datepicker('disable');
                $('form.clickToEditForm input[type=button]').removeAttr('disabled');
                
                $('form input.editButton').click(function(){
                    $('form.clickToEditForm input, form.clickToEditForm select, form.clickToEditForm textarea').removeAttr('disabled');
                    $('form.clickToEditForm input.calendar').datepicker('enable');
                });
                
                /* Enabling/disabling form fields: End */
                
            });
            
                

    
    


/html[@class=&quot;fontawesome-i2svg-active fontawesome-i2svg-complete&quot;]Le Thi Hoa</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;fontawesome-i2svg-active fontawesome-i2svg-complete&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//html</value>
   </webElementXpaths>
</WebElementEntity>
