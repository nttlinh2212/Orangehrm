<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Test Suite Data</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>0a8ed10c-a560-4b32-b843-c3636861c019</testSuiteGuid>
   <testCaseLink>
      <guid>6fef29ab-9199-40e3-98f3-5322a0ecde1a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test Case Data Driven</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>1ea287b8-2693-40ab-bb96-60713dc2992b</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Test Data</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>1ea287b8-2693-40ab-bb96-60713dc2992b</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Use Role</value>
         <variableId>98b5bf11-37c1-40e2-9967-edc91e12870b</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>1ea287b8-2693-40ab-bb96-60713dc2992b</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Employee Name</value>
         <variableId>7043b6a5-b63c-4d0c-ad37-3b160ebf31fc</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>1ea287b8-2693-40ab-bb96-60713dc2992b</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Username </value>
         <variableId>e9ed904c-293d-4d67-bfc3-84d1694767a8</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>1ea287b8-2693-40ab-bb96-60713dc2992b</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Status</value>
         <variableId>f991c124-75a3-49b5-9680-f5542280fc81</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>1ea287b8-2693-40ab-bb96-60713dc2992b</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Password </value>
         <variableId>5ab67a83-2f98-4aae-a741-235bc69cd2a1</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>1ea287b8-2693-40ab-bb96-60713dc2992b</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Confirm Password</value>
         <variableId>c81ea71e-06da-4e01-8e1d-8372aef27f2b</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>1ea287b8-2693-40ab-bb96-60713dc2992b</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>expectedresult</value>
         <variableId>4a8bdcd0-6cc5-42b9-8b59-f01e403b7620</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
