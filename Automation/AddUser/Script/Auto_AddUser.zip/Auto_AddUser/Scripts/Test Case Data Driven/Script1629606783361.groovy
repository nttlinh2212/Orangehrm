import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

CustomKeywords.'com.database.mysql.connectDB'('localhost', 'orangehrm_mysql', '3306', 'root', null)

CustomKeywords.'com.database.mysql.execute'('DELETE FROM `ohrm_user` WHERE `ohrm_user`.`user_name` = \'hoa123\'')

CustomKeywords.'com.database.mysql.closeDatabaseConnection'()

WebUI.openBrowser('')

WebUI.navigateToUrl('http://localhost/orangehrm/orangehrm-4.5/symfony/web/index.php/auth/login')

WebUI.click(findTestObject('Object Repository/Page_OrangeHRM/span_Username'))

WebUI.setText(findTestObject('Object Repository/Page_OrangeHRM/input_LOGIN Panel_txtUsername'), 'admin')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_OrangeHRM/input_Username_txtPassword'), 'OJ5pvyq/3K4ywSlMT7FtRQ==')

WebUI.click(findTestObject('Object Repository/Page_OrangeHRM/input_Password_Submit'))

WebUI.click(findTestObject('Object Repository/Page_OrangeHRM/b_Admin'))

WebUI.click(findTestObject('Object Repository/Page_OrangeHRM/input_Status_btnAdd'))

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_OrangeHRM/select_AdminESS'), user_role, true)

WebUI.setText(findTestObject('Object Repository/Page_OrangeHRM/input__systemUseremployeeNameempName'), emp_name)

WebUI.setText(findTestObject('Object Repository/Page_OrangeHRM/input__systemUseruserName'), username)

WebUI.setText(findTestObject('Object Repository/Page_OrangeHRM/input__systemUserpassword'), password)

WebUI.setText(findTestObject('Object Repository/Page_OrangeHRM/input__systemUserconfirmPassword'), confirm_password)

WebUI.click(findTestObject('Object Repository/Page_OrangeHRM/input__btnSave'))

WebUI.click(findTestObject('Page_OrangeHRM/b_Admin'))

WebUI.setText(findTestObject('Page_OrangeHRM/input_Username_searchSystemUseruserName'), username)

WebUI.click(findTestObject('Page_OrangeHRM/input_Status__search'))

if (expectedresult.equals('YES')) {
    WebUI.verifyElementVisible(findTestObject('Page_OrangeHRM/td_hoa123'))
}

if (expectedresult.equals('NO')) {
	WebUI.verifyElementVisible(findTestObject('Page_OrangeHRM/td_No Records Found'))
}

WebUI.closeBrowser()


